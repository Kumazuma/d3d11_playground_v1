#pragma once
#include <cstdint>
#include <windows.h>

#ifdef D3D11GRAPHICSMODULE_EXPORTS
#define D3D11_GRAPHICS_MODULE_API __declspec(dllexport)
#else
#define D3D11GRAPHICSMODULE_API __declspec(dllimport)
#endif

namespace grapics {
	class RenderTarget
	{
	public:
		virtual ~RenderTarget() = default;
		virtual void Resize(uint32_t width, uint32_t height) = 0;
	};

	class RenderManager
	{
	public:
		virtual ~RenderManager() = default;
		virtual void Render(RenderTarget* outputTarget) = 0;
	};

	class Object
	{
	public:
		virtual ~Object() = default;

	};

	class D3D11_GRAPHICS_MODULE_API GraphicsModule {
	public:
		GraphicsModule(void);
		virtual ~GraphicsModule() = default;
		static GraphicsModule* New();
		virtual RenderTarget* CreateRenderTarget(HWND hWindow, UINT width, UINT height) = 0;
		virtual RenderManager* CreateRenderManager() = 0;
	};
}
