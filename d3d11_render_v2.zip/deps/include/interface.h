#pragma once
#include <cstdint>

class GraphicsRenderTarget
{
public:
	virtual ~GraphicsRenderTarget() = default;
	virtual void Resize(uint32_t width, uint32_t height) = 0;
};

class GraphicsRenderManager
{
public:
	virtual ~GraphicsRenderManager() = default;
	virtual void Render(GraphicsRenderTarget* outputTarget) = 0;
};

class GraphicsRenderObject
{
public:
	virtual ~GraphicsRenderObject() = default;

};
