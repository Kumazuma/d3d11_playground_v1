#include "pch.h"
#include "RenderFrame.h"

RenderFrame::RenderFrame(wxWindow* window, wxWindowID id, const wxString& title)
	: wxFrame(window, id, title)
{

}
