﻿// d3d11_graphics_module.cpp : DLL을 위해 내보낸 함수를 정의합니다.
//

#include "pch.h"
#include "framework.h"
#include "d3d11_graphics_module.h"


// 내보낸 변수의 예제입니다.
D3D11_GRAPHICS_MODULE_API int nd3d11graphicsmodule=0;

// 내보낸 함수의 예제입니다.
D3D11_GRAPHICS_MODULE_API int fnd3d11graphicsmodule(void)
{
    return 0;
}

// 내보낸 클래스의 생성자입니다.
GraphicsModule::GraphicsModule()
{
    return;
}

GraphicsModule* GraphicsModule::New()
{
    return nullptr;
}
