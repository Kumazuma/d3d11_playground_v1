#pragma once
#include <cstdint>

class GraphicsRenderTarget
{
public:
	virtual ~GraphicsRenderTarget() = default;
	virtual void Resize(uint32_t width, uint32_t height) = 0;
};
