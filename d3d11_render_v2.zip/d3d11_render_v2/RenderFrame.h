#pragma once
#include <wx/wx.h>
class RenderFrame: public wxFrame
{
public:
	RenderFrame(wxWindow* window, wxWindowID id, const wxString& title);

private:

};

